python3 a1.py
