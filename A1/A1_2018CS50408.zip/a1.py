#!/usr/bin/env python
# coding: utf-8

# In[127]:


#using low rank approximation for lossy data compression of image 


# In[128]:


#a) split function to take image and 
import numpy as np 
from matplotlib.image import imread
import matplotlib.pyplot as plt
from scipy.linalg import svd

def split(img,n):
    h,w,_ = img.shape  
    rows = h//n
    cols = w//n  #calcs number of rows and cols of image
    C = np.zeros((rows*cols,3*n*n)) #create a new matrix C 
    for i in range(rows):
        for j in range(cols):#iterates over img of each blclk & create matrxi
            block = img[i*n:(i+1)*n,j*n:(j+1)*n]
            C[i*cols + j] = block.reshape(-1)
    print("split function is happening")
    return C


# In[129]:


def join(C,n,w,h):#func reconstruct the image with matrix C
    rows = h//n
    cols = w//n
    img = np.zeros((h,w,3))
    for i in range(rows):
        for j in range(cols):
            block = C[i*cols + j].reshape(n,n,3)
            img[i*n:(i+1)*n,j*n:(j+1)*n] = block 
    print("func in the join")
    return img


# In[130]:


#optimal rank optimization is done by SVD of matrix

def compress(C,r):
    U,s,Vh = svd(C)
    A = U[:, :r]
    B = np.diag(s[:r]) @Vh[:r]
    rel_error = np.sqrt(np.sum(s[r:]**2))/np.sqrt(np.sum(s**2))
    return A,B,rel_error


# In[131]:


def relError(img,img2):
    
    return np.linalg.norm(img-img2)/np.linalg.norm(img)


# In[ ]:





# In[132]:


img=imread('kodim.png')
# plt.imshow(img)
print(img.size)
print(img.shape)


# In[133]:


C= split(img,16)
#Note:larger  value of n will result into more compres but low image
#large value of r means less compress and high image quality


# In[134]:


A,B,rel_error = compress(C,10)# replace r with desired rnk of approximation


# In[135]:


img2 = join(A @B,16,768,512) #replace n,w,h of new image (blocksize,width,height)


# In[136]:


fig,ax = plt.subplots(1,2)
# ax[0].imshow(img)
plt.imshow(img)
ax[0].set_title('Original ')
ax[0].imshow(img2)
ax[0].set_title('rebuild one')
plt.show()


# In[ ]:





# In[ ]:




