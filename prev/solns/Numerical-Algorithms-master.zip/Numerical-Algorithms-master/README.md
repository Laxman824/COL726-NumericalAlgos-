# Numerical-Algorithms

Projects done in COL 726 - Numerical Algorithms, 2018
